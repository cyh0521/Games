window.QUESTION_BANK = window.QUESTION_BANK || {};
window.QUESTION_BANK["臺灣特色美食"] = [
  {
    "answer": "滷肉飯",
    "clue": "將切碎豬肉以醬油與香料慢燉，淋在白飯上的經典庶民美食。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "將切碎豬肉以醬油與香料慢燉，淋在白飯上的經典庶民美食。"
  },
  {
    "answer": "肉燥飯",
    "clue": "以細碎豬肉炒香滷製，鹹香醬汁非常下飯。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以細碎豬肉炒香滷製，鹹香醬汁非常下飯。"
  },
  {
    "answer": "雞肉飯",
    "clue": "白飯鋪上撕成細絲的雞肉，再淋上香氣濃郁的雞油醬汁。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "白飯鋪上撕成細絲的雞肉，再淋上香氣濃郁的雞油醬汁。"
  },
  {
    "answer": "排骨飯",
    "clue": "以炸或滷排骨搭配白飯與配菜，是常見的臺式便當料理。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以炸或滷排骨搭配白飯與配菜，是常見的臺式便當料理。"
  },
  {
    "answer": "筒仔米糕",
    "clue": "糯米與肉料放入小筒中蒸熟，倒扣後食用。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "糯米與肉料放入小筒中蒸熟，倒扣後食用。"
  },
  {
    "answer": "油飯",
    "clue": "糯米拌入香菇、肉絲等配料炒製，常見於彌月與節慶場合。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "糯米拌入香菇、肉絲等配料炒製，常見於彌月與節慶場合。"
  },
  {
    "answer": "菜飯",
    "clue": "米飯加入蔬菜與配料一起燜煮，口味樸實家常。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "米飯加入蔬菜與配料一起燜煮，口味樸實家常。"
  },
  {
    "answer": "擔仔麵",
    "clue": "小碗麵條搭配肉燥、蝦子等配料，是臺南代表性小吃。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "小碗麵條搭配肉燥、蝦子等配料，是臺南代表性小吃。"
  },
  {
    "answer": "麻醬麵",
    "clue": "麵條拌上濃郁芝麻醬，香氣厚實滑順。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "麵條拌上濃郁芝麻醬，香氣厚實滑順。"
  },
  {
    "answer": "肉羹麵",
    "clue": "以裹粉肉條搭配勾芡羹湯與麵條，是常見臺式小吃。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以裹粉肉條搭配勾芡羹湯與麵條，是常見臺式小吃。"
  },
  {
    "answer": "大麵羹",
    "clue": "粗麵條帶有特殊鹼香，搭配濃稠湯汁，是臺中特色小吃。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "粗麵條帶有特殊鹼香，搭配濃稠湯汁，是臺中特色小吃。"
  },
  {
    "answer": "牛肉麵",
    "clue": "以燉煮牛肉、湯頭與麵條組成，是臺灣具代表性的麵食。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以燉煮牛肉、湯頭與麵條組成，是臺灣具代表性的麵食。"
  },
  {
    "answer": "米苔目",
    "clue": "以米製成短粗條狀，可做鹹食也可搭配冰品甜湯。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以米製成短粗條狀，可做鹹食也可搭配冰品甜湯。"
  },
  {
    "answer": "粄條",
    "clue": "以米漿製成寬扁麵條，常見於客家料理。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以米漿製成寬扁麵條，常見於客家料理。"
  },
  {
    "answer": "飯糰",
    "clue": "糯米包入油條、菜脯、肉鬆等配料，是常見臺式早餐。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "糯米包入油條、菜脯、肉鬆等配料，是常見臺式早餐。"
  },
  {
    "answer": "肉粽",
    "clue": "糯米包入豬肉等餡料，再以竹葉包裹蒸煮或水煮。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "糯米包入豬肉等餡料，再以竹葉包裹蒸煮或水煮。"
  },
  {
    "answer": "碗粿",
    "clue": "米漿蒸成柔軟糕體，常加入肉燥、香菇等鹹香配料。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "米漿蒸成柔軟糕體，常加入肉燥、香菇等鹹香配料。"
  },
  {
    "answer": "蘿蔔糕",
    "clue": "以白蘿蔔與米漿製成，煎至表面微焦後特別香。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以白蘿蔔與米漿製成，煎至表面微焦後特別香。"
  },
  {
    "answer": "芋粿巧",
    "clue": "以芋頭與米製成彎曲粿體，口感軟Q、芋香明顯。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以芋頭與米製成彎曲粿體，口感軟Q、芋香明顯。"
  },
  {
    "answer": "肉圓",
    "clue": "外皮Q彈透明，包入豬肉、筍丁等餡料，可蒸可炸。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "外皮Q彈透明，包入豬肉、筍丁等餡料，可蒸可炸。"
  },
  {
    "answer": "蚵仔煎",
    "clue": "鮮蚵、雞蛋與粉漿煎成，搭配甜鹹醬汁食用。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "鮮蚵、雞蛋與粉漿煎成，搭配甜鹹醬汁食用。"
  },
  {
    "answer": "臭豆腐",
    "clue": "經發酵產生特殊氣味，常炸至外酥內嫩並搭配泡菜。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "經發酵產生特殊氣味，常炸至外酥內嫩並搭配泡菜。"
  },
  {
    "answer": "大腸包小腸",
    "clue": "糯米腸剖開後夾入臺式香腸，再加入配料調味。",
    "difficulty": 2,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "糯米腸剖開後夾入臺式香腸，再加入配料調味。"
  },
  {
    "answer": "臺灣香腸",
    "clue": "帶有甜鹹風味的豬肉香腸，常以炭烤方式料理。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "帶有甜鹹風味的豬肉香腸，常以炭烤方式料理。"
  },
  {
    "answer": "鹽酥雞",
    "clue": "將雞肉與多種食材油炸，再加入胡椒鹽與九層塔調味。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "將雞肉與多種食材油炸，再加入胡椒鹽與九層塔調味。"
  },
  {
    "answer": "雞排",
    "clue": "大片雞胸肉裹粉油炸，是臺灣夜市常見的人氣小吃。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "大片雞胸肉裹粉油炸，是臺灣夜市常見的人氣小吃。"
  },
  {
    "answer": "甜不辣",
    "clue": "以魚漿製成各種形狀，口感彈牙，可炸食或煮食。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以魚漿製成各種形狀，口感彈牙，可炸食或煮食。"
  },
  {
    "answer": "蔥油餅",
    "clue": "麵糰加入青蔥後煎製，外層香酥、內裡帶有蔥香。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "麵糰加入青蔥後煎製，外層香酥、內裡帶有蔥香。"
  },
  {
    "answer": "蔥抓餅",
    "clue": "多層次麵餅煎熟後抓鬆，口感酥脆又帶嚼勁。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "多層次麵餅煎熟後抓鬆，口感酥脆又帶嚼勁。"
  },
  {
    "answer": "蛋餅",
    "clue": "薄餅皮搭配雞蛋煎製，是臺灣早餐店代表性餐點。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "薄餅皮搭配雞蛋煎製，是臺灣早餐店代表性餐點。"
  },
  {
    "answer": "胡椒餅",
    "clue": "酥香餅皮包入胡椒調味肉餡與青蔥，以高溫烘烤。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "酥香餅皮包入胡椒調味肉餡與青蔥，以高溫烘烤。"
  },
  {
    "answer": "水煎包",
    "clue": "包子底部以油水煎出焦香脆皮，內餡多為肉或蔬菜。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "包子底部以油水煎出焦香脆皮，內餡多為肉或蔬菜。"
  },
  {
    "answer": "韭菜盒",
    "clue": "麵皮包入大量韭菜等餡料，再煎至表面金黃。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "麵皮包入大量韭菜等餡料，再煎至表面金黃。"
  },
  {
    "answer": "車輪餅",
    "clue": "圓形餅皮包入紅豆、奶油等餡料，現烤現吃。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "圓形餅皮包入紅豆、奶油等餡料，現烤現吃。"
  },
  {
    "answer": "雙胞胎",
    "clue": "兩條麵糰交纏後油炸，外酥內Q並帶有甜味。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "兩條麵糰交纏後油炸，外酥內Q並帶有甜味。"
  },
  {
    "answer": "白糖粿",
    "clue": "糯米糰油炸後裹上糖粉或花生粉，外酥內軟。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "糯米糰油炸後裹上糖粉或花生粉，外酥內軟。"
  },
  {
    "answer": "蚵嗲",
    "clue": "麵糊包入鮮蚵、韭菜等餡料後油炸，外皮酥脆。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "麵糊包入鮮蚵、韭菜等餡料後油炸，外皮酥脆。"
  },
  {
    "answer": "棺材板",
    "clue": "厚片吐司炸至酥脆，中間挖空填入濃稠鹹味餡料。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "厚片吐司炸至酥脆，中間挖空填入濃稠鹹味餡料。"
  },
  {
    "answer": "潤餅",
    "clue": "薄潤餅皮包入多種蔬菜、肉類與花生粉後捲起食用。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "薄潤餅皮包入多種蔬菜、肉類與花生粉後捲起食用。"
  },
  {
    "answer": "刈包",
    "clue": "半月形蒸麵皮夾入滷肉、酸菜、花生粉等配料。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "半月形蒸麵皮夾入滷肉、酸菜、花生粉等配料。"
  },
  {
    "answer": "阿給",
    "clue": "油豆腐中塞入冬粉，再以魚漿封口蒸熟，是淡水名物。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "油豆腐中塞入冬粉，再以魚漿封口蒸熟，是淡水名物。"
  },
  {
    "answer": "魚酥",
    "clue": "以魚肉加工炸製成香酥零嘴，口感鬆脆。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以魚肉加工炸製成香酥零嘴，口感鬆脆。"
  },
  {
    "answer": "鼎邊趖",
    "clue": "以米漿沿鍋邊製成薄片，再加入海鮮等煮成湯食。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以米漿沿鍋邊製成薄片，再加入海鮮等煮成湯食。"
  },
  {
    "answer": "四神湯",
    "clue": "以豬腸搭配薏仁、蓮子等中藥食材熬煮的溫補湯品。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以豬腸搭配薏仁、蓮子等中藥食材熬煮的溫補湯品。"
  },
  {
    "answer": "排骨酥湯",
    "clue": "醃製排骨炸酥後再蒸煮，湯頭濃郁帶有胡椒香。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "醃製排骨炸酥後再蒸煮，湯頭濃郁帶有胡椒香。"
  },
  {
    "answer": "麻油雞",
    "clue": "以麻油、老薑與雞肉煮成，冬天特別常見。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以麻油、老薑與雞肉煮成，冬天特別常見。"
  },
  {
    "answer": "薑母鴨",
    "clue": "鴨肉加入老薑與中藥材熬煮，是冬季人氣鍋物。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "鴨肉加入老薑與中藥材熬煮，是冬季人氣鍋物。"
  },
  {
    "answer": "羊肉爐",
    "clue": "羊肉搭配中藥材燉煮，常在寒冷天氣食用。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "羊肉搭配中藥材燉煮，常在寒冷天氣食用。"
  },
  {
    "answer": "藥燉排骨",
    "clue": "排骨與中藥材長時間熬煮，湯色深且香氣濃厚。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "排骨與中藥材長時間熬煮，湯色深且香氣濃厚。"
  },
  {
    "answer": "滷味",
    "clue": "將豆製品、肉類等食材放入滷汁中燉煮入味。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "將豆製品、肉類等食材放入滷汁中燉煮入味。"
  },
  {
    "answer": "滷蛋",
    "clue": "雞蛋經醬油與香料滷煮後，蛋白呈現褐色並帶鹹香味。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "雞蛋經醬油與香料滷煮後，蛋白呈現褐色並帶鹹香味。"
  },
  {
    "answer": "菜脯蛋",
    "clue": "雞蛋加入切碎蘿蔔乾煎製，鹹香下飯。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "雞蛋加入切碎蘿蔔乾煎製，鹹香下飯。"
  },
  {
    "answer": "三杯雞",
    "clue": "以麻油、醬油與米酒調味，搭配九層塔炒出濃郁香氣。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以麻油、醬油與米酒調味，搭配九層塔炒出濃郁香氣。"
  },
  {
    "answer": "客家小炒",
    "clue": "以魷魚、豬肉、豆干等食材大火快炒，香氣濃郁。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以魷魚、豬肉、豆干等食材大火快炒，香氣濃郁。"
  },
  {
    "answer": "蒼蠅頭",
    "clue": "以韭菜花、絞肉與豆豉拌炒，名稱特殊但不含昆蟲。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以韭菜花、絞肉與豆豉拌炒，名稱特殊但不含昆蟲。"
  },
  {
    "answer": "鹹蛋苦瓜",
    "clue": "苦瓜搭配鹹蛋黃拌炒，鹹香可降低苦味。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "苦瓜搭配鹹蛋黃拌炒，鹹香可降低苦味。"
  },
  {
    "answer": "豆乳雞",
    "clue": "雞肉以豆腐乳醃製後油炸，帶有獨特發酵香氣。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "雞肉以豆腐乳醃製後油炸，帶有獨特發酵香氣。"
  },
  {
    "answer": "白菜滷",
    "clue": "白菜與多種配料燉煮至軟爛，是常見臺式家常菜。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "白菜與多種配料燉煮至軟爛，是常見臺式家常菜。"
  },
  {
    "answer": "佛跳牆",
    "clue": "多種高級食材放入甕中長時間燉煮，是宴席常見大菜。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "多種高級食材放入甕中長時間燉煮，是宴席常見大菜。"
  },
  {
    "answer": "紅蟳米糕",
    "clue": "糯米飯上鋪放紅蟳一起蒸製，是傳統宴席料理。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "糯米飯上鋪放紅蟳一起蒸製，是傳統宴席料理。"
  },
  {
    "answer": "白斬雞",
    "clue": "雞肉以水煮熟後切盤，重點在保留鮮嫩原味。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "雞肉以水煮熟後切盤，重點在保留鮮嫩原味。"
  },
  {
    "answer": "鹽水雞",
    "clue": "雞肉以鹽水煮熟或浸泡入味，常冷盤切食。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "雞肉以鹽水煮熟或浸泡入味，常冷盤切食。"
  },
  {
    "answer": "紅燒蹄膀",
    "clue": "整塊豬蹄膀以醬油與香料慢燉至軟嫩入味。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "整塊豬蹄膀以醬油與香料慢燉至軟嫩入味。"
  },
  {
    "answer": "花枝丸",
    "clue": "以花枝漿製成圓球狀，口感彈牙鮮甜。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以花枝漿製成圓球狀，口感彈牙鮮甜。"
  },
  {
    "answer": "鳳梨酥",
    "clue": "酥鬆外皮包入酸甜鳳梨餡，是知名臺灣伴手禮。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "酥鬆外皮包入酸甜鳳梨餡，是知名臺灣伴手禮。"
  },
  {
    "answer": "太陽餅",
    "clue": "多層酥皮包入麥芽糖餡，外形扁圓且容易掉屑。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "多層酥皮包入麥芽糖餡，外形扁圓且容易掉屑。"
  },
  {
    "answer": "芋頭酥",
    "clue": "酥皮呈層次紋理，內餡帶有濃郁芋頭香。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "酥皮呈層次紋理，內餡帶有濃郁芋頭香。"
  },
  {
    "answer": "蛋黃酥",
    "clue": "酥皮中包入豆沙與鹹蛋黃，是中秋常見糕點。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "酥皮中包入豆沙與鹹蛋黃，是中秋常見糕點。"
  },
  {
    "answer": "牛舌餅",
    "clue": "外形細長扁平，餅皮香酥，因形狀像牛舌而得名。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "外形細長扁平，餅皮香酥，因形狀像牛舌而得名。"
  },
  {
    "answer": "米香",
    "clue": "米粒經膨發後以糖漿黏合，口感香甜酥脆。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "米粒經膨發後以糖漿黏合，口感香甜酥脆。"
  },
  {
    "answer": "麻荖",
    "clue": "外層裹滿芝麻的傳統炸製米食點心，口感酥香。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "外層裹滿芝麻的傳統炸製米食點心，口感酥香。"
  },
  {
    "answer": "寸棗",
    "clue": "短條狀油炸麵點，外層裹糖，常見於傳統年節。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "短條狀油炸麵點，外層裹糖，常見於傳統年節。"
  },
  {
    "answer": "沙琪瑪",
    "clue": "炸麵條以糖漿黏合成塊，口感鬆軟香甜。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "炸麵條以糖漿黏合成塊，口感鬆軟香甜。"
  },
  {
    "answer": "麥芽餅",
    "clue": "餅乾中夾入黏稠麥芽糖，甜香且富有嚼勁。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "餅乾中夾入黏稠麥芽糖，甜香且富有嚼勁。"
  },
  {
    "answer": "傳統大餅",
    "clue": "大型圓餅包入豆沙、肉燥等餡料，常見於婚嫁喜慶。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "大型圓餅包入豆沙、肉燥等餡料，常見於婚嫁喜慶。"
  },
  {
    "answer": "紅龜粿",
    "clue": "紅色龜形糯米粿，象徵吉祥長壽，常見於祭祀節慶。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "紅色龜形糯米粿，象徵吉祥長壽，常見於祭祀節慶。"
  },
  {
    "answer": "甜粿",
    "clue": "以糯米製成黏Q甜糕，過年時特別常見。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以糯米製成黏Q甜糕，過年時特別常見。"
  },
  {
    "answer": "豆花",
    "clue": "以黃豆製成柔嫩凝固甜品，可搭配糖水與各種配料。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以黃豆製成柔嫩凝固甜品，可搭配糖水與各種配料。"
  },
  {
    "answer": "仙草",
    "clue": "以仙草植物熬煮製成黑色滑嫩凍狀甜品。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以仙草植物熬煮製成黑色滑嫩凍狀甜品。"
  },
  {
    "answer": "剉冰",
    "clue": "將冰塊刨成細碎冰屑，再加入糖水與多種配料。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "將冰塊刨成細碎冰屑，再加入糖水與多種配料。"
  },
  {
    "answer": "芒果冰",
    "clue": "刨冰上鋪滿新鮮芒果，常搭配煉乳或冰淇淋。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "刨冰上鋪滿新鮮芒果，常搭配煉乳或冰淇淋。"
  },
  {
    "answer": "芋圓",
    "clue": "以芋頭與澱粉製成Q彈圓粒，是九份著名甜點。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以芋頭與澱粉製成Q彈圓粒，是九份著名甜點。"
  },
  {
    "answer": "麻糬",
    "clue": "以糯米製成柔軟黏Q點心，常裹花生粉或芝麻粉。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以糯米製成柔軟黏Q點心，常裹花生粉或芝麻粉。"
  },
  {
    "answer": "牛軋糖",
    "clue": "以糖、奶粉、堅果等製成，口感有嚼勁且奶香濃郁。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以糖、奶粉、堅果等製成，口感有嚼勁且奶香濃郁。"
  },
  {
    "answer": "鹹豆漿",
    "clue": "熱豆漿加入醋、醬油與配料後凝結，帶有鹹香風味。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "熱豆漿加入醋、醬油與配料後凝結，帶有鹹香風味。"
  },
  {
    "answer": "豆漿",
    "clue": "以黃豆磨製煮成的飲品，是臺式早餐經典搭配。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以黃豆磨製煮成的飲品，是臺式早餐經典搭配。"
  },
  {
    "answer": "燒餅",
    "clue": "層次酥脆的烤麵餅，常夾油條或雞蛋一起食用。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "層次酥脆的烤麵餅，常夾油條或雞蛋一起食用。"
  },
  {
    "answer": "油條",
    "clue": "長條形油炸麵食，外酥內空，常搭配豆漿食用。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "長條形油炸麵食，外酥內空，常搭配豆漿食用。"
  },
  {
    "answer": "饅頭",
    "clue": "以麵粉發酵蒸製而成，口感鬆軟，可甜可鹹。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以麵粉發酵蒸製而成，口感鬆軟，可甜可鹹。"
  },
  {
    "answer": "米漿",
    "clue": "以米與花生等研磨煮成，質地濃稠並帶有烘焙香氣。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以米與花生等研磨煮成，質地濃稠並帶有烘焙香氣。"
  },
  {
    "answer": "杏仁茶",
    "clue": "以杏仁製成的傳統熱飲，香氣濃郁、口感滑順。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "以杏仁製成的傳統熱飲，香氣濃郁、口感滑順。"
  },
  {
    "answer": "麵茶",
    "clue": "炒熟麵粉加入糖與熱水沖泡，帶有濃厚穀物香氣。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "炒熟麵粉加入糖與熱水沖泡，帶有濃厚穀物香氣。"
  },
  {
    "answer": "珍珠奶茶",
    "clue": "奶茶加入黑色Q彈粉圓，是臺灣最具國際知名度的飲品之一。",
    "difficulty": 1,
    "source": "使用者提供",
    "chapter": "臺灣特色美食",
    "explanation": "奶茶加入黑色Q彈粉圓，是臺灣最具國際知名度的飲品之一。"
  }
];
